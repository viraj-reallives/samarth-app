import * as Application from 'expo-application';
import * as WebBrowser from 'expo-web-browser';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LanguageToggle from '../../src/components/LanguageToggle';
import ScreenHeader from '../../src/components/ScreenHeader';
import { useT } from '../../src/i18n';
import { colors, radius, space, type } from '../../src/theme';

const SITE = 'https://www.samarthramdas400.in';

export default function AboutScreen() {
  const t = useT();

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <ScreenHeader title={t('tab.about')} />

      <ScrollView contentContainerStyle={styles.body}>
        <Text style={styles.invocation}>{t('about.invocation')}</Text>

        <Text style={type.body}>{t('about.body')}</Text>

        <View style={styles.divider} />

        <View style={styles.section}>
          <Text style={type.eyebrow}>{t('about.language')}</Text>
          <LanguageToggle />
          <Text style={type.meta}>{t('about.languageHint')}</Text>
        </View>

        <Pressable
          style={styles.link}
          onPress={() => WebBrowser.openBrowserAsync(SITE)}
          accessibilityRole="link"
        >
          <Text style={type.button}>{t('about.openSite')}</Text>
          <Text style={type.meta}>samarthramdas400.in</Text>
        </Pressable>

        <Text style={[type.meta, styles.version]}>
          {t('about.version', { version: Application.nativeApplicationVersion ?? '1.0.0' })}
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.paper },
  body: { padding: space.lg, gap: space.lg },
  invocation: { ...type.workTitleLarge, color: colors.saffron, textAlign: 'center' },
  divider: { height: StyleSheet.hairlineWidth, backgroundColor: colors.rule },
  section: { gap: space.sm },
  link: {
    padding: space.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.rule,
    backgroundColor: colors.card,
    gap: 2,
  },
  version: { textAlign: 'center', marginTop: space.lg },
});
