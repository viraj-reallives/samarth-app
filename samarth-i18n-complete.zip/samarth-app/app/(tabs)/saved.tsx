import { Feather } from '@expo/vector-icons';
import { Link } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import ScreenHeader from '../../src/components/ScreenHeader';
import { kindKey, useT, useTitles } from '../../src/i18n';
import { useSavedWorks } from '../../src/lib/saved';
import { colors, space, type } from '../../src/theme';

type SavedItem = ReturnType<typeof useSavedWorks>[number];

function Row({ item }: { item: SavedItem }) {
  const t = useT();
  const titles = useTitles(item);

  return (
    <Link href={`/work/${item.slug}`} asChild>
      <Pressable style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
        <Feather
          name={item.kind === 'audio' ? 'headphones' : 'book-open'}
          size={16}
          color={colors.inkSoft}
          style={styles.icon}
        />
        <View style={styles.text}>
          <Text style={type.eyebrow}>{t(kindKey(item.kind))}</Text>
          <Text style={type.workTitle} numberOfLines={2}>
            {titles.primary}
          </Text>
        </View>
      </Pressable>
    </Link>
  );
}

export default function SavedScreen() {
  const t = useT();
  const saved = useSavedWorks();

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <ScreenHeader
        title={t('tab.saved')}
        subtitle={saved.length ? t('saved.count', { count: saved.length }) : undefined}
      />

      <FlatList
        data={saved}
        keyExtractor={(item) => item.slug}
        contentContainerStyle={saved.length === 0 && styles.emptyContainer}
        renderItem={({ item }) => <Row item={item} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="bookmark" size={26} color={colors.inkFaint} />
            <Text style={type.body}>{t('saved.empty')}</Text>
            <Text style={[type.meta, styles.hint]}>{t('saved.emptyHint')}</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.paper },
  row: {
    flexDirection: 'row',
    gap: space.md,
    paddingVertical: space.md,
    paddingHorizontal: space.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.rule,
  },
  rowPressed: { backgroundColor: colors.saffronWash },
  icon: { paddingTop: 18 },
  text: { flex: 1 },
  emptyContainer: { flexGrow: 1, justifyContent: 'center' },
  empty: { alignItems: 'center', gap: space.sm, padding: space.xl },
  hint: { textAlign: 'center' },
});
